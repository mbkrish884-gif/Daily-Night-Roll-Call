"use client";

import { useMemo, useState } from "react";
import type { RecordRow } from "@/lib/types";
import { ATTENDANCE_STATUSES, STATUS_LABELS } from "@/lib/config";
import { formatIstTime } from "@/lib/date";
import { StatusBadge } from "./StatusBadge";

interface Props {
  initialRows: RecordRow[];
  date: string;
  dateLabel: string;
  platoon: string;
}

export function AttendanceTable({ initialRows, date, dateLabel, platoon }: Props) {
  const [rows, setRows] = useState<RecordRow[]>(initialRows);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [unitFilter, setUnitFilter] = useState("ALL");
  const [savingId, setSavingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const units = useMemo(
    () => Array.from(new Set(rows.map((r) => r.unit).filter(Boolean))) as string[],
    [rows]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (statusFilter !== "ALL" && r.status !== statusFilter) return false;
      if (unitFilter !== "ALL" && r.unit !== unitFilter) return false;
      if (q && !`${r.pcNumber} ${r.name ?? ""} ${r.rank}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [rows, search, statusFilter, unitFilter]);

  async function patch(recordId: string, body: Record<string, unknown>) {
    setSavingId(recordId);
    setError(null);
    const prev = rows;
    try {
      const res = await fetch("/api/admin/attendance", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recordId, ...body }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.error || "Save failed.");
        setRows(prev); // revert
      }
    } catch {
      setError("Network error while saving.");
      setRows(prev);
    } finally {
      setSavingId(null);
    }
  }

  function setLocal(recordId: string, patchObj: Partial<RecordRow>) {
    setRows((rs) => rs.map((r) => (r.id === recordId ? { ...r, ...patchObj } : r)));
  }

  function onStatusChange(r: RecordRow, status: string) {
    setLocal(r.id, { status });
    patch(r.id, { status });
  }

  function onDutyBlur(r: RecordRow, field: "dutyLocation" | "dutyRemarks", value: string) {
    const v = value.trim() || null;
    if (v === r[field]) return;
    setLocal(r.id, { [field]: v } as Partial<RecordRow>);
    patch(r.id, { [field]: v });
  }

  function exportCsv() {
    const headers = [
      "Sl",
      "PC Number",
      "Rank",
      "Name",
      "Unit",
      "Mobile",
      "Status",
      "Present Time",
      "Distance (m)",
      "Duty Location",
      "Remarks",
      "Source",
    ];
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = filtered.map((r) =>
      [
        r.slNo,
        r.pcNumber,
        r.rank,
        r.name ?? "",
        r.unit ?? "",
        r.mobile ?? "",
        STATUS_LABELS[r.status as keyof typeof STATUS_LABELS] ?? r.status,
        r.presentAt ? formatIstTime(r.presentAt) : "",
        r.distanceM ?? "",
        r.dutyLocation ?? "",
        r.dutyRemarks ?? "",
        r.source,
      ]
        .map(esc)
        .join(",")
    );
    const csv = [headers.map(esc).join(","), ...lines].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `rollcall_${date}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="no-print flex flex-wrap items-center gap-2">
        <input
          className="field max-w-[220px] py-2"
          placeholder="Search PC no. / name"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="field max-w-[170px] py-2" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="ALL">All statuses</option>
          {ATTENDANCE_STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS[s]}
            </option>
          ))}
        </select>
        <select className="field max-w-[150px] py-2" value={unitFilter} onChange={(e) => setUnitFilter(e.target.value)}>
          <option value="ALL">All units</option>
          {units.map((u) => (
            <option key={u} value={u}>
              {u}
            </option>
          ))}
        </select>
        <div className="ml-auto flex gap-2">
          <button onClick={exportCsv} className="btn-ghost">
            Export CSV
          </button>
          <button onClick={() => window.print()} className="btn-ghost">
            Print
          </button>
        </div>
      </div>

      {error && <p className="no-print rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

      {/* Printable header */}
      <div className="hidden print:block">
        <h2 className="text-lg font-bold">Night Roll Call — {platoon} Platoon</h2>
        <p className="text-sm">CAR Headquarters, Hyderabad · {dateLabel}</p>
      </div>

      {/* Table */}
      <div className="print-area overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[920px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">PC / G.No</th>
              <th className="px-3 py-2">Rank</th>
              <th className="px-3 py-2">Name</th>
              <th className="px-3 py-2">Unit</th>
              <th className="px-3 py-2">Mobile</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Present time</th>
              <th className="px-3 py-2">Duty location</th>
              <th className="px-3 py-2">Remarks</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((r) => (
              <tr key={r.id} className={savingId === r.id ? "bg-amber-50/50" : ""}>
                <td className="px-3 py-2 text-slate-400">{r.slNo}</td>
                <td className="px-3 py-2 font-semibold text-ink">{r.pcNumber}</td>
                <td className="px-3 py-2">{r.rank}</td>
                <td className="px-3 py-2">{r.name || <span className="text-slate-300">—</span>}</td>
                <td className="px-3 py-2">{r.unit || <span className="text-slate-300">—</span>}</td>
                <td className="px-3 py-2">{r.mobile || <span className="text-slate-300">—</span>}</td>
                <td className="px-3 py-2">
                  <span className="no-print">
                    <select
                      className="rounded-md border border-slate-300 bg-white px-2 py-1 text-sm"
                      value={r.status}
                      onChange={(e) => onStatusChange(r, e.target.value)}
                    >
                      {ATTENDANCE_STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {STATUS_LABELS[s]}
                        </option>
                      ))}
                    </select>
                  </span>
                  <span className="hidden print:inline">
                    <StatusBadge status={r.status} />
                  </span>
                  {r.distanceM != null && (
                    <div className="mt-0.5 text-[11px] text-slate-400">{r.distanceM} m from HQ</div>
                  )}
                </td>
                <td className="px-3 py-2 text-slate-600">{formatIstTime(r.presentAt)}</td>
                <td className="px-3 py-2">
                  <input
                    className="w-36 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    defaultValue={r.dutyLocation ?? ""}
                    placeholder="—"
                    onBlur={(e) => onDutyBlur(r, "dutyLocation", e.target.value)}
                  />
                </td>
                <td className="px-3 py-2">
                  <input
                    className="w-44 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    defaultValue={r.dutyRemarks ?? ""}
                    placeholder="—"
                    onBlur={(e) => onDutyBlur(r, "dutyRemarks", e.target.value)}
                  />
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={10} className="px-3 py-8 text-center text-slate-400">
                  No PCs match the current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400">
        Showing {filtered.length} of {rows.length}. Status &amp; remarks auto-save on change; every edit
        is recorded in the audit trail.
      </p>
    </div>
  );
}
