"use client";

import type { RecordRow, SummaryCounts } from "@/lib/types";
import { STATUS_LABELS } from "@/lib/config";
import { formatIstTime } from "@/lib/date";

interface Props {
  rows: RecordRow[];
  counts: SummaryCounts;
  date: string;
  dateLabel: string;
  platoon: string;
}

export function ReportActions({ rows, date }: Props) {
  function exportCsv() {
    const headers = [
      "Sl",
      "PC Number",
      "Rank",
      "Name",
      "Unit",
      "Mobile",
      "Status",
      "Present Time",
      "Distance (m)",
      "Geofence OK",
      "Duty Location",
      "Remarks",
      "Source",
    ];
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const lines = rows.map((r) =>
      [
        r.slNo,
        r.pcNumber,
        r.rank,
        r.name ?? "",
        r.unit ?? "",
        r.mobile ?? "",
        STATUS_LABELS[r.status as keyof typeof STATUS_LABELS] ?? r.status,
        r.presentAt ? formatIstTime(r.presentAt) : "",
        r.distanceM ?? "",
        r.geofenceOk == null ? "" : r.geofenceOk ? "YES" : "NO",
        r.dutyLocation ?? "",
        r.dutyRemarks ?? "",
        r.source,
      ]
        .map(esc)
        .join(",")
    );
    const csv = [headers.map(esc).join(","), ...lines].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `rollcall_report_${date}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex gap-2">
      <button onClick={exportCsv} className="btn-ghost">
        Export CSV
      </button>
      <button onClick={() => window.print()} className="btn-ghost">
        Print / PDF
      </button>
    </div>
  );
}
