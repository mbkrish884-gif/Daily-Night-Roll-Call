"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

interface Hq {
  name: string;
  mapsUrl: string | null;
  latitude: number;
  longitude: number;
  radiusM: number;
}

export function SettingsForm({ hq }: { hq: Hq }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: hq.name,
    mapsUrl: hq.mapsUrl ?? "",
    latitude: String(hq.latitude),
    longitude: String(hq.longitude),
    radiusM: String(hq.radiusM),
  });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  function set(field: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      setMsg({ kind: "err", text: "Geolocation not available in this browser." });
      return;
    }
    setMsg(null);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        set("latitude", pos.coords.latitude.toFixed(6));
        set("longitude", pos.coords.longitude.toFixed(6));
        setMsg({
          kind: "ok",
          text: `Filled current location (±${Math.round(pos.coords.accuracy)} m accuracy). Stand at the HQ roll-call point for best results.`,
        });
      },
      (err) => setMsg({ kind: "err", text: `Could not read location: ${err.message}` }),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function save() {
    const lat = Number(form.latitude);
    const lng = Number(form.longitude);
    const radius = parseInt(form.radiusM, 10);
    if (Number.isNaN(lat) || Number.isNaN(lng)) {
      setMsg({ kind: "err", text: "Latitude and longitude must be valid numbers." });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/admin/hq", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          mapsUrl: form.mapsUrl.trim() || null,
          latitude: lat,
          longitude: lng,
          radiusM: radius,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setMsg({ kind: "err", text: data.error || "Save failed." });
      } else {
        setMsg({ kind: "ok", text: "HQ geofence updated." });
        router.refresh();
      }
    } catch {
      setMsg({ kind: "err", text: "Network error while saving." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
        <b>Set the real HQ coordinates.</b> Open the official location link, read the latitude/longitude,
        and enter them below — or stand at the roll-call point and tap “Use my current location”. Until
        this is correct, the geofence uses a placeholder and attendance may be wrongly allowed or blocked.
      </div>

      <div className="grid gap-4 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-2">
        <label className="text-sm sm:col-span-2">
          <span className="mb-1 block font-medium text-slate-600">HQ name</span>
          <input className="field py-2" value={form.name} onChange={(e) => set("name", e.target.value)} />
        </label>
        <label className="text-sm sm:col-span-2">
          <span className="mb-1 block font-medium text-slate-600">Maps URL (reference)</span>
          <input
            className="field py-2"
            value={form.mapsUrl}
            onChange={(e) => set("mapsUrl", e.target.value)}
            placeholder="https://maps.app.goo.gl/…"
          />
        </label>
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Latitude</span>
          <input
            className="field py-2"
            value={form.latitude}
            onChange={(e) => set("latitude", e.target.value)}
            inputMode="decimal"
          />
        </label>
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Longitude</span>
          <input
            className="field py-2"
            value={form.longitude}
            onChange={(e) => set("longitude", e.target.value)}
            inputMode="decimal"
          />
        </label>
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Geofence radius (metres)</span>
          <input
            className="field py-2"
            value={form.radiusM}
            onChange={(e) => set("radiusM", e.target.value)}
            inputMode="numeric"
          />
          <span className="mt-1 block text-xs text-slate-400">
            Typical: 100–200 m. Larger values tolerate GPS drift but allow attendance from farther away.
          </span>
        </label>
        <div className="flex items-end">
          <button className="btn-ghost" onClick={useMyLocation} type="button">
            Use my current location
          </button>
        </div>
      </div>

      {msg && (
        <p
          className={`rounded-md px-3 py-2 text-sm ${
            msg.kind === "ok" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
          }`}
        >
          {msg.text}
        </p>
      )}

      <div className="flex justify-end">
        <button className="btn-primary" onClick={save} disabled={busy}>
          {busy ? "Saving…" : "Save geofence"}
        </button>
      </div>
    </div>
  );
}
