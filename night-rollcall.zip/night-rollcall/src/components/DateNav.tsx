"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

function shift(date: string, n: number): string {
  const d = new Date(date + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function DateNav({ date, basePath }: { date: string; basePath: string }) {
  const router = useRouter();
  const [value, setValue] = useState(date);

  function go(d: string) {
    setValue(d);
    router.push(`${basePath}?date=${d}`);
  }

  return (
    <div className="flex items-center gap-2">
      <button className="btn-ghost px-3" onClick={() => go(shift(value, -1))} aria-label="Previous day">
        ←
      </button>
      <input
        type="date"
        className="field max-w-[170px] py-2"
        value={value}
        onChange={(e) => e.target.value && go(e.target.value)}
      />
      <button className="btn-ghost px-3" onClick={() => go(shift(value, 1))} aria-label="Next day">
        →
      </button>
    </div>
  );
}
