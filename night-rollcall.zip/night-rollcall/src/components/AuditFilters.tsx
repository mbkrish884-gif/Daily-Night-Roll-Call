"use client";

import { useRouter } from "next/navigation";

interface Props {
  entity: string;
  action: string;
  date: string;
  entities: string[];
  actions: string[];
}

export function AuditFilters({ entity, action, date, entities, actions }: Props) {
  const router = useRouter();

  function apply(next: Partial<{ entity: string; action: string; date: string }>) {
    const params = new URLSearchParams();
    const e = next.entity ?? entity;
    const a = next.action ?? action;
    const d = next.date ?? date;
    if (e && e !== "ALL") params.set("entity", e);
    if (a && a !== "ALL") params.set("action", a);
    if (d) params.set("date", d);
    const qs = params.toString();
    router.push(`/admin/audit${qs ? `?${qs}` : ""}`);
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <select
        className="field max-w-[160px] py-2"
        value={entity || "ALL"}
        onChange={(e) => apply({ entity: e.target.value })}
      >
        <option value="ALL">All entities</option>
        {entities.map((x) => (
          <option key={x} value={x}>
            {x}
          </option>
        ))}
      </select>
      <select
        className="field max-w-[200px] py-2"
        value={action || "ALL"}
        onChange={(e) => apply({ action: e.target.value })}
      >
        <option value="ALL">All actions</option>
        {actions.map((x) => (
          <option key={x} value={x}>
            {x}
          </option>
        ))}
      </select>
      <input
        type="date"
        className="field max-w-[170px] py-2"
        value={date}
        onChange={(e) => apply({ date: e.target.value })}
      />
      {(entity || action || date) && (
        <button className="btn-ghost" onClick={() => router.push("/admin/audit")}>
          Clear
        </button>
      )}
    </div>
  );
}
