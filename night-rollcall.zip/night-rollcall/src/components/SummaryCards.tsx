import type { SummaryCounts } from "@/lib/types";
import { STATUS_COLORS } from "@/lib/config";

const CARDS: { key: keyof SummaryCounts; label: string; color: string }[] = [
  { key: "total", label: "On Roster", color: "#0f172a" },
  { key: "present", label: "Present", color: STATUS_COLORS.PRESENT },
  { key: "available", label: "Available", color: STATUS_COLORS.AVAILABLE },
  { key: "duty", label: "On Duty", color: STATUS_COLORS.DUTY_ASSIGNED },
  { key: "off", label: "Off", color: STATUS_COLORS.OFF },
  { key: "absent", label: "Absent", color: STATUS_COLORS.ABSENT },
  { key: "pending", label: "Not marked", color: STATUS_COLORS.PENDING },
];

export function SummaryCards({ counts }: { counts: SummaryCounts }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
      {CARDS.map((c) => (
        <div key={c.key} className="rounded-xl border border-slate-200 bg-white p-3">
          <div className="text-2xl font-bold" style={{ color: c.color }}>
            {counts[c.key]}
          </div>
          <div className="text-xs font-medium text-slate-500">{c.label}</div>
        </div>
      ))}
    </div>
  );
}
