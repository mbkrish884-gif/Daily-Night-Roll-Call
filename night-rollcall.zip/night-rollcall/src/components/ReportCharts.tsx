"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import type { SummaryCounts } from "@/lib/types";
import { STATUS_COLORS, STATUS_LABELS } from "@/lib/config";

export function ReportCharts({ counts }: { counts: SummaryCounts }) {
  const barData = [
    { key: "PRESENT", label: STATUS_LABELS.PRESENT, value: counts.present, color: STATUS_COLORS.PRESENT },
    { key: "AVAILABLE", label: STATUS_LABELS.AVAILABLE, value: counts.available, color: STATUS_COLORS.AVAILABLE },
    { key: "DUTY_ASSIGNED", label: STATUS_LABELS.DUTY_ASSIGNED, value: counts.duty, color: STATUS_COLORS.DUTY_ASSIGNED },
    { key: "OFF", label: STATUS_LABELS.OFF, value: counts.off, color: STATUS_COLORS.OFF },
    { key: "ABSENT", label: STATUS_LABELS.ABSENT, value: counts.absent, color: STATUS_COLORS.ABSENT },
    { key: "PENDING", label: STATUS_LABELS.PENDING, value: counts.pending, color: STATUS_COLORS.PENDING },
  ];

  // Where is the strength right now: at HQ (present+available), out on duty, or unavailable.
  const atHq = counts.present + counts.available;
  const onDuty = counts.duty;
  const unavailable = counts.off + counts.absent;
  const pending = counts.pending;
  const pieData = [
    { name: "At HQ", value: atHq, color: "#16a34a" },
    { name: "On Duty", value: onDuty, color: STATUS_COLORS.DUTY_ASSIGNED },
    { name: "Off / Absent", value: unavailable, color: STATUS_COLORS.ABSENT },
    { name: "Not marked", value: pending, color: STATUS_COLORS.PENDING },
  ].filter((d) => d.value > 0);

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <h3 className="mb-3 text-sm font-semibold text-ink">Status breakdown</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} margin={{ top: 8, right: 8, left: -16, bottom: 8 }}>
              <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} angle={-12} textAnchor="end" height={50} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ fill: "#f1f5f9" }} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {barData.map((d) => (
                  <Cell key={d.key} fill={d.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <h3 className="mb-3 text-sm font-semibold text-ink">Deployment summary</h3>
        <div className="h-64">
          {pieData.length === 0 ? (
            <div className="flex h-full items-center justify-center text-sm text-slate-400">
              No marked attendance yet.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={2}
                >
                  {pieData.map((d) => (
                    <Cell key={d.name} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
