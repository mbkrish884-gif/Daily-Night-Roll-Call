import { STATUS_COLORS, STATUS_LABELS, type AttendanceStatus } from "@/lib/config";

export function StatusBadge({ status }: { status: string }) {
  const s = (status as AttendanceStatus) in STATUS_LABELS ? (status as AttendanceStatus) : "PENDING";
  const color = STATUS_COLORS[s];
  return (
    <span
      className="pill"
      style={{ backgroundColor: `${color}1a`, color, border: `1px solid ${color}55` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
      {STATUS_LABELS[s]}
    </span>
  );
}
