"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

interface Entry {
  pcNumber: string;
  rank: string;
  name: string;
  unit: string;
  mobile: string;
  dutyRemarks: string;
}

interface Props {
  date: string;
  platoon: string;
  rollCallTime: string;
  instructions: string;
  existing: Entry[];
}

const EMPTY: Entry = { pcNumber: "", rank: "PC", name: "", unit: "", mobile: "", dutyRemarks: "" };

export function RosterManager({ date, platoon, rollCallTime, instructions, existing }: Props) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);

  const [rows, setRows] = useState<Entry[]>(existing.length ? existing : []);
  const [meta, setMeta] = useState({ date, platoon, rollCallTime, instructions });
  const [replace, setReplace] = useState(true);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);

  function update(i: number, field: keyof Entry, value: string) {
    setRows((rs) => rs.map((r, idx) => (idx === i ? { ...r, [field]: value } : r)));
  }
  function removeRow(i: number) {
    setRows((rs) => rs.filter((_, idx) => idx !== i));
  }
  function addRow() {
    setRows((rs) => [...rs, { ...EMPTY }]);
  }

  function mergeEntries(incoming: Entry[], mode: "replace" | "append") {
    setRows((rs) => {
      const base = mode === "replace" ? [] : [...rs];
      const seen = new Set(base.map((r) => r.pcNumber));
      for (const e of incoming) {
        if (!e.pcNumber || seen.has(e.pcNumber)) continue;
        seen.add(e.pcNumber);
        base.push(e);
      }
      return base;
    });
  }

  function normalize(raw: any[]): Entry[] {
    return raw.map((e) => ({
      pcNumber: String(e.pcNumber ?? "").trim(),
      rank: String(e.rank ?? "PC").trim() || "PC",
      name: String(e.name ?? "").trim(),
      unit: String(e.unit ?? "").trim(),
      mobile: String(e.mobile ?? "").trim(),
      dutyRemarks: String(e.dutyRemarks ?? "").trim(),
    }));
  }

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setMsg(null);
    setWarnings([]);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/admin/roster/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setMsg({ kind: "err", text: data.error || "Upload failed." });
      } else {
        const entries = normalize(data.entries ?? []);
        mergeEntries(entries, replace ? "replace" : "append");
        setWarnings(data.warnings ?? []);
        if (data.instructions) setMeta((m) => ({ ...m, instructions: data.instructions }));
        if (data.platoon) setMeta((m) => ({ ...m, platoon: data.platoon }));
        setMsg({ kind: "ok", text: `${entries.length} PC(s) loaded from file. Review below, then Commit.` });
      }
    } catch {
      setMsg({ kind: "err", text: "Network error during upload." });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function applyPaste() {
    // Accept comma- or tab-separated lines: PC, Rank, Name, Unit, Mobile, Remarks
    const lines = pasteText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const out: Entry[] = [];
    for (const line of lines) {
      const cols = line.split(/\t|,/).map((c) => c.trim());
      const pc = cols[0]?.replace(/\.0+$/, "");
      if (!pc || /^(g\.?no|pc|sl)/i.test(pc)) continue; // skip header-ish lines
      out.push({
        pcNumber: pc,
        rank: cols[1] || "PC",
        name: cols[2] || "",
        unit: cols[3] || "",
        mobile: (cols[4] || "").replace(/\.0+$/, ""),
        dutyRemarks: cols[5] || "",
      });
    }
    if (out.length === 0) {
      setMsg({ kind: "err", text: "No usable rows found in pasted text." });
      return;
    }
    mergeEntries(out, replace ? "replace" : "append");
    setPasteText("");
    setPasteOpen(false);
    setMsg({ kind: "ok", text: `${out.length} PC(s) added from pasted text.` });
  }

  async function commit() {
    const entries = rows
      .map((r) => ({ ...r, pcNumber: r.pcNumber.trim() }))
      .filter((r) => r.pcNumber);
    if (entries.length === 0) {
      setMsg({ kind: "err", text: "Add at least one PC before committing." });
      return;
    }
    const dupes = entries.map((e) => e.pcNumber).filter((v, i, a) => a.indexOf(v) !== i);
    if (dupes.length) {
      setMsg({ kind: "err", text: `Duplicate PC number(s): ${Array.from(new Set(dupes)).join(", ")}` });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/admin/roster/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date: meta.date,
          platoon: meta.platoon || "NIGHT",
          rollCallTime: meta.rollCallTime || "19:00",
          instructions: meta.instructions || undefined,
          replace,
          entries: entries.map((e) => ({
            pcNumber: e.pcNumber,
            rank: e.rank || undefined,
            name: e.name || undefined,
            unit: e.unit || undefined,
            mobile: e.mobile || undefined,
            dutyRemarks: e.dutyRemarks || undefined,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setMsg({ kind: "err", text: data.error || "Commit failed." });
      } else {
        setMsg({
          kind: "ok",
          text: `Roster saved for ${meta.date}: ${data.created ?? entries.length} PC(s). Opening dashboard…`,
        });
        if (meta.date !== date) router.push(`/admin/roster?date=${meta.date}`);
        router.refresh();
      }
    } catch {
      setMsg({ kind: "err", text: "Network error during commit." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      {/* Roster meta */}
      <div className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4">
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Roster date</span>
          <input
            type="date"
            className="field py-2"
            value={meta.date}
            onChange={(e) => setMeta((m) => ({ ...m, date: e.target.value }))}
          />
        </label>
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Platoon</span>
          <input
            className="field py-2"
            value={meta.platoon}
            onChange={(e) => setMeta((m) => ({ ...m, platoon: e.target.value }))}
          />
        </label>
        <label className="text-sm">
          <span className="mb-1 block font-medium text-slate-600">Roll call time</span>
          <input
            type="time"
            className="field py-2"
            value={meta.rollCallTime}
            onChange={(e) => setMeta((m) => ({ ...m, rollCallTime: e.target.value }))}
          />
        </label>
        <label className="flex items-end text-sm">
          <span className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2.5">
            <input type="checkbox" checked={replace} onChange={(e) => setReplace(e.target.checked)} />
            <span className="font-medium text-slate-600">Replace existing roster</span>
          </span>
        </label>
        <label className="text-sm sm:col-span-2 lg:col-span-4">
          <span className="mb-1 block font-medium text-slate-600">Standing order / instructions</span>
          <textarea
            className="field min-h-[64px] py-2"
            value={meta.instructions}
            onChange={(e) => setMeta((m) => ({ ...m, instructions: e.target.value }))}
            placeholder="e.g. Report before the duty officer at 7:00 PM…"
          />
        </label>
      </div>

      {/* Import controls */}
      <div className="flex flex-wrap items-center gap-2">
        <input
          ref={fileRef}
          type="file"
          accept=".xlsx,.xls,.csv,.tsv,.txt"
          className="hidden"
          onChange={onFile}
        />
        <button className="btn-ghost" onClick={() => fileRef.current?.click()} disabled={busy}>
          Upload Excel / CSV
        </button>
        <button className="btn-ghost" onClick={() => setPasteOpen((v) => !v)} disabled={busy}>
          Paste rows
        </button>
        <button className="btn-ghost" onClick={addRow} disabled={busy}>
          + Add PC
        </button>
        <button className="btn-ghost" onClick={() => setRows([])} disabled={busy || rows.length === 0}>
          Clear
        </button>
        <div className="ml-auto">
          <button className="btn-primary" onClick={commit} disabled={busy}>
            {busy ? "Saving…" : "Commit roster"}
          </button>
        </div>
      </div>

      {pasteOpen && (
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="mb-2 text-sm text-slate-600">
            One PC per line: <code>PC/G.No, Rank, Name, Unit, Mobile, Remarks</code> (comma or tab
            separated). Header lines are skipped automatically.
          </p>
          <textarea
            className="field min-h-[120px] font-mono text-sm"
            value={pasteText}
            onChange={(e) => setPasteText(e.target.value)}
            placeholder={"11809, PC, RAMESH, CIVIL, 7075107981, \n10349, PC, , , ,"}
          />
          <div className="mt-2 flex gap-2">
            <button className="btn-primary" onClick={applyPaste}>
              Add pasted rows
            </button>
            <button className="btn-ghost" onClick={() => setPasteOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {msg && (
        <p
          className={`rounded-md px-3 py-2 text-sm ${
            msg.kind === "ok" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
          }`}
        >
          {msg.text}
        </p>
      )}
      {warnings.length > 0 && (
        <div className="rounded-md bg-amber-50 px-3 py-2 text-sm text-amber-800">
          <b>Notes:</b>
          <ul className="ml-4 list-disc">
            {warnings.map((w, i) => (
              <li key={i}>{w}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Editable roster table */}
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[820px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">PC / G.No *</th>
              <th className="px-3 py-2">Rank</th>
              <th className="px-3 py-2">Name</th>
              <th className="px-3 py-2">Unit</th>
              <th className="px-3 py-2">Mobile</th>
              <th className="px-3 py-2">Duty remarks</th>
              <th className="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map((r, i) => (
              <tr key={i}>
                <td className="px-3 py-1.5 text-slate-400">{i + 1}</td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-24 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.pcNumber}
                    onChange={(e) => update(i, "pcNumber", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-16 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.rank}
                    onChange={(e) => update(i, "rank", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-40 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.name}
                    onChange={(e) => update(i, "name", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-24 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.unit}
                    onChange={(e) => update(i, "unit", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-32 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.mobile}
                    onChange={(e) => update(i, "mobile", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <input
                    className="w-48 rounded-md border border-slate-200 px-2 py-1 text-sm focus:border-khaki"
                    value={r.dutyRemarks}
                    onChange={(e) => update(i, "dutyRemarks", e.target.value)}
                  />
                </td>
                <td className="px-3 py-1.5">
                  <button
                    className="rounded-md px-2 py-1 text-xs font-semibold text-red-600 hover:bg-red-50"
                    onClick={() => removeRow(i)}
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-8 text-center text-slate-400">
                  No PCs yet. Upload a file, paste rows, or add manually.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400">
        {rows.length} PC(s) staged. Committing creates/updates the roster and a PENDING attendance
        record per PC; existing Present marks are preserved unless “Replace” is on.
      </p>
    </div>
  );
}
