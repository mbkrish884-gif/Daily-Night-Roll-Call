import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { hqUpdateSchema } from "@/lib/validation";
import { getActiveHq } from "@/lib/hq";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }
  const parsed = hqUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input." },
      { status: 400 }
    );
  }

  const current = await getActiveHq();
  const updated = await prisma.hqLocation.update({
    where: { id: current.id },
    data: {
      name: parsed.data.name,
      mapsUrl: parsed.data.mapsUrl ?? null,
      latitude: parsed.data.latitude,
      longitude: parsed.data.longitude,
      radiusM: parsed.data.radiusM,
    },
  });

  await writeAudit({
    actorId: session.sub,
    actorLabel: `admin:${session.username}`,
    action: "UPDATE_HQ",
    entity: "hq",
    entityId: updated.id,
    oldValue: `${current.latitude},${current.longitude},r=${current.radiusM}`,
    newValue: `${updated.latitude},${updated.longitude},r=${updated.radiusM}`,
  });

  return NextResponse.json({ ok: true, hq: updated });
}
