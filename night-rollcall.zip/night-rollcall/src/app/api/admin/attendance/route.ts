import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { adminAttendanceUpdateSchema } from "@/lib/validation";
import { writeAudit } from "@/lib/audit";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }
  const parsed = adminAttendanceUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input." },
      { status: 400 }
    );
  }
  const { recordId, status, dutyLocation, dutyRemarks } = parsed.data;

  const record = await prisma.attendanceRecord.findUnique({ where: { id: recordId } });
  if (!record) return NextResponse.json({ ok: false, error: "Record not found." }, { status: 404 });

  const actorLabel = `admin:${session.username}`;
  const data: Record<string, unknown> = { editedById: session.sub, source: "admin" };
  const audits: Promise<unknown>[] = [];
  const now = new Date();

  if (status !== undefined && status !== record.status) {
    data.status = status;
    data.markedAt = now;
    if (status === "PRESENT" && !record.presentAt) data.presentAt = now;
    if (status !== "PRESENT") {
      // keep historical geo data but null out present timestamp for non-present
      data.presentAt = null;
    }
    audits.push(
      writeAudit({
        actorId: session.sub,
        actorLabel,
        action: "ADMIN_UPDATE_STATUS",
        entity: "attendance",
        attendanceId: recordId,
        field: "status",
        oldValue: record.status,
        newValue: status,
      })
    );
  }
  if (dutyLocation !== undefined && dutyLocation !== record.dutyLocation) {
    data.dutyLocation = dutyLocation;
    audits.push(
      writeAudit({
        actorId: session.sub,
        actorLabel,
        action: "ADMIN_EDIT_DUTY_LOCATION",
        entity: "attendance",
        attendanceId: recordId,
        field: "dutyLocation",
        oldValue: record.dutyLocation,
        newValue: dutyLocation,
      })
    );
  }
  if (dutyRemarks !== undefined && dutyRemarks !== record.dutyRemarks) {
    data.dutyRemarks = dutyRemarks;
    audits.push(
      writeAudit({
        actorId: session.sub,
        actorLabel,
        action: "ADMIN_EDIT_REMARKS",
        entity: "attendance",
        attendanceId: recordId,
        field: "dutyRemarks",
        oldValue: record.dutyRemarks,
        newValue: dutyRemarks,
      })
    );
  }

  const updated = await prisma.attendanceRecord.update({ where: { id: recordId }, data });
  await Promise.all(audits);

  return NextResponse.json({ ok: true, record: updated });
}
