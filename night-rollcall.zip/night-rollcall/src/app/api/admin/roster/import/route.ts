import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { rosterImportSchema } from "@/lib/validation";
import { applyRoster } from "@/lib/roster-service";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }
  const parsed = rosterImportSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid roster." },
      { status: 400 }
    );
  }

  const result = await applyRoster({
    ...parsed.data,
    actorId: session.sub,
    actorLabel: `admin:${session.username}`,
  });

  revalidatePath("/admin");
  revalidatePath("/admin/roster");
  return NextResponse.json({ ok: true, ...result });
}
