import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { parseRosterFile } from "@/lib/roster-parse";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ ok: false, error: "No file uploaded." }, { status: 400 });
  }
  if (file.size > 5 * 1024 * 1024) {
    return NextResponse.json({ ok: false, error: "File too large (max 5 MB)." }, { status: 400 });
  }

  const buf = Buffer.from(await file.arrayBuffer());
  try {
    const parsed = parseRosterFile(file.name, buf);
    return NextResponse.json({ ok: true, ...parsed });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: `Could not read file: ${(e as Error).message}` },
      { status: 400 }
    );
  }
}
