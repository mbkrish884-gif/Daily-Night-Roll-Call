import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { todayKey } from "@/lib/date";
import { attendanceSubmitSchema } from "@/lib/validation";
import { getActiveHq } from "@/lib/hq";
import { validateGeofence } from "@/lib/geo";
import { writeAudit } from "@/lib/audit";
import { formatIstTime } from "@/lib/date";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
  }

  const parsed = attendanceSubmitSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input." },
      { status: 400 }
    );
  }
  const input = parsed.data;
  const date = todayKey();

  const entry = await prisma.dailyRosterEntry.findFirst({
    where: { roster: { date }, pc: { pcNumber: input.pcNumber } },
    include: { pc: true, attendance: true },
  });
  if (!entry || !entry.attendance) {
    return NextResponse.json(
      { ok: false, error: "This PC number is not on tonight's roster." },
      { status: 404 }
    );
  }

  const record = entry.attendance;
  const actorLabel = `self:PC${entry.pc.pcNumber}`;
  const now = new Date(); // server time is the source of truth

  // Prevent duplicate Present submissions.
  if (input.status === "PRESENT" && record.status === "PRESENT") {
    return NextResponse.json({
      ok: true,
      duplicate: true,
      status: "PRESENT",
      presentAt: record.presentAt,
      message: `Already marked Present at ${formatIstTime(record.presentAt)}.`,
    });
  }

  // Geofence enforcement for PRESENT.
  if (input.status === "PRESENT") {
    const hq = await getActiveHq();
    const check = validateGeofence({
      lat: input.latitude!,
      lng: input.longitude!,
      accuracyM: input.accuracyM ?? null,
      hqLat: hq.latitude,
      hqLng: hq.longitude,
      radiusM: hq.radiusM,
    });

    if (!check.ok) {
      await writeAudit({
        actorLabel,
        action: "BLOCKED_OUT_OF_ZONE",
        entity: "attendance",
        attendanceId: record.id,
        meta: {
          distanceM: Math.round(check.distanceM),
          radiusM: hq.radiusM,
          lat: input.latitude,
          lng: input.longitude,
          accuracyM: input.accuracyM,
        },
      });
      return NextResponse.json(
        {
          ok: false,
          blocked: true,
          error: "Attendance not allowed outside HQ location.",
          distanceM: Math.round(check.distanceM),
          allowedM: hq.radiusM,
        },
        { status: 403 }
      );
    }

    const updated = await prisma.attendanceRecord.update({
      where: { id: record.id },
      data: {
        status: "PRESENT",
        presentAt: now,
        markedAt: now,
        latitude: input.latitude,
        longitude: input.longitude,
        accuracyM: input.accuracyM ?? null,
        distanceM: Math.round(check.distanceM),
        geofenceOk: true,
        source: "self",
        ...(input.remarks ? { dutyRemarks: input.remarks } : {}),
      },
    });
    await writeAudit({
      actorLabel,
      action: "MARK_PRESENT",
      entity: "attendance",
      attendanceId: record.id,
      field: "status",
      oldValue: record.status,
      newValue: "PRESENT",
      meta: { distanceM: Math.round(check.distanceM), presentAt: now.toISOString() },
    });
    return NextResponse.json({
      ok: true,
      status: "PRESENT",
      presentAt: updated.presentAt,
      message: `Present marked at ${formatIstTime(updated.presentAt)} (${Math.round(check.distanceM)} m from HQ).`,
    });
  }

  // Non-present statuses: no geolocation required, just record status + time.
  const updated = await prisma.attendanceRecord.update({
    where: { id: record.id },
    data: {
      status: input.status,
      markedAt: now,
      presentAt: null,
      latitude: null,
      longitude: null,
      distanceM: null,
      geofenceOk: null,
      source: "self",
      ...(input.remarks ? { dutyRemarks: input.remarks } : {}),
    },
  });
  await writeAudit({
    actorLabel,
    action: "MARK_STATUS",
    entity: "attendance",
    attendanceId: record.id,
    field: "status",
    oldValue: record.status,
    newValue: input.status,
  });

  return NextResponse.json({
    ok: true,
    status: updated.status,
    message: `Marked ${updated.status.replace("_", " ").toLowerCase()} at ${formatIstTime(now)}.`,
  });
}
