import { getDayData } from "@/lib/queries";
import { toDayKey, formatDay, todayKey } from "@/lib/date";
import { DateNav } from "@/components/DateNav";
import { AttendanceTable } from "@/components/AttendanceTable";
import { SummaryCards } from "@/components/SummaryCards";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: { date?: string };
}) {
  const date = toDayKey(searchParams.date ?? todayKey());
  const data = await getDayData(date);

  return (
    <div className="space-y-5">
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink">Daily Roll Call</h1>
          <p className="text-sm text-slate-500">
            {data.platoon} platoon · {formatDay(date)} · roll call {data.rollCallTime}
          </p>
        </div>
        <DateNav date={date} basePath="/admin" />
      </div>

      {!data.rosterExists ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center">
          <p className="text-slate-600">No roster found for {formatDay(date)}.</p>
          <Link href="/admin/roster" className="btn-primary mt-3">
            Create / import roster
          </Link>
        </div>
      ) : (
        <>
          <SummaryCards counts={data.counts} />
          {data.instructions && (
            <div className="no-print rounded-lg border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-800">
              <b>Standing order:</b> {data.instructions}
            </div>
          )}
          <AttendanceTable
            initialRows={data.rows}
            date={date}
            dateLabel={formatDay(date)}
            platoon={data.platoon}
          />
        </>
      )}
    </div>
  );
}
