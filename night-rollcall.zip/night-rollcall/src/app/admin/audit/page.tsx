import { prisma } from "@/lib/db";
import { formatIstDateTime, toDayKey } from "@/lib/date";
import { AuditFilters } from "@/components/AuditFilters";

export const dynamic = "force-dynamic";

const ENTITIES = ["attendance", "roster", "hq", "user"];
const ACTIONS = [
  "MARK_PRESENT",
  "MARK_STATUS",
  "ADMIN_UPDATE_STATUS",
  "ADMIN_EDIT_REMARKS",
  "ADMIN_EDIT_DUTY_LOCATION",
  "IMPORT_ROSTER",
  "RESET_ROSTER",
  "UPDATE_HQ",
  "BLOCKED_OUT_OF_ZONE",
  "LOGIN",
];

export default async function AuditPage({
  searchParams,
}: {
  searchParams: { entity?: string; action?: string; date?: string };
}) {
  const entity = searchParams.entity ?? "";
  const action = searchParams.action ?? "";
  const date = searchParams.date ?? "";

  const where: Record<string, unknown> = {};
  if (entity) where.entity = entity;
  if (action) where.action = action;
  if (date) {
    const day = toDayKey(date);
    const start = new Date(day + "T00:00:00+05:30");
    const end = new Date(day + "T23:59:59.999+05:30");
    where.at = { gte: start, lte: end };
  }

  const logs = await prisma.auditLog.findMany({
    where,
    orderBy: { at: "desc" },
    take: 300,
  });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-ink">Audit Trail</h1>
        <p className="text-sm text-slate-500">
          Every attendance edit, roster import, and configuration change is recorded here.
        </p>
      </div>

      <AuditFilters entity={entity} action={action} date={date} entities={ENTITIES} actions={ACTIONS} />

      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full min-w-[860px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-3 py-2">When (IST)</th>
              <th className="px-3 py-2">Actor</th>
              <th className="px-3 py-2">Action</th>
              <th className="px-3 py-2">Entity</th>
              <th className="px-3 py-2">Field</th>
              <th className="px-3 py-2">Old → New</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {logs.map((l) => (
              <tr key={l.id}>
                <td className="whitespace-nowrap px-3 py-2 text-slate-600">{formatIstDateTime(l.at)}</td>
                <td className="px-3 py-2">{l.actorLabel}</td>
                <td className="px-3 py-2">
                  <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-700">
                    {l.action}
                  </span>
                </td>
                <td className="px-3 py-2 text-slate-600">
                  {l.entity}
                  {l.entityId ? <span className="text-slate-400"> · {l.entityId.slice(0, 8)}</span> : null}
                </td>
                <td className="px-3 py-2 text-slate-600">{l.field || "—"}</td>
                <td className="px-3 py-2 text-slate-600">
                  {l.oldValue || l.newValue ? (
                    <span>
                      <span className="text-slate-400">{l.oldValue || "∅"}</span>
                      <span className="mx-1">→</span>
                      <span className="font-medium text-ink">{l.newValue || "∅"}</span>
                    </span>
                  ) : l.meta ? (
                    <span className="text-slate-400">{l.meta}</span>
                  ) : (
                    "—"
                  )}
                </td>
              </tr>
            ))}
            {logs.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3 py-8 text-center text-slate-400">
                  No audit entries match the current filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400">Showing the most recent {logs.length} entries (max 300).</p>
    </div>
  );
}
