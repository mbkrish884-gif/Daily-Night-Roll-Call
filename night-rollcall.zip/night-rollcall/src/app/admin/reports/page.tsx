import { getDayData } from "@/lib/queries";
import { toDayKey, formatDay, todayKey, formatIstTime } from "@/lib/date";
import { DateNav } from "@/components/DateNav";
import { SummaryCards } from "@/components/SummaryCards";
import { ReportCharts } from "@/components/ReportCharts";
import { ReportActions } from "@/components/ReportActions";
import { StatusBadge } from "@/components/StatusBadge";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: { date?: string };
}) {
  const date = toDayKey(searchParams.date ?? todayKey());
  const data = await getDayData(date);
  const dateLabel = formatDay(date);

  const dutyRows = data.rows.filter((r) => r.status === "DUTY_ASSIGNED");
  const markedPct =
    data.counts.total > 0
      ? Math.round(((data.counts.total - data.counts.pending) / data.counts.total) * 100)
      : 0;

  return (
    <div className="space-y-5">
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink">Reports</h1>
          <p className="text-sm text-slate-500">
            {data.platoon} platoon · {dateLabel} · {markedPct}% marked
          </p>
        </div>
        <div className="flex items-center gap-2">
          <DateNav date={date} basePath="/admin/reports" />
          <ReportActions rows={data.rows} counts={data.counts} date={date} dateLabel={dateLabel} platoon={data.platoon} />
        </div>
      </div>

      {!data.rosterExists ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center">
          <p className="text-slate-600">No roster found for {dateLabel}.</p>
          <Link href="/admin/roster" className="btn-primary mt-3">
            Create / import roster
          </Link>
        </div>
      ) : (
        <>
          {/* Printable header */}
          <div className="hidden print:block">
            <h2 className="text-lg font-bold">Night Roll Call — {data.platoon} Platoon (Report)</h2>
            <p className="text-sm">CAR Headquarters, Hyderabad · {dateLabel}</p>
          </div>

          <SummaryCards counts={data.counts} />
          <div className="no-print">
            <ReportCharts counts={data.counts} />
          </div>

          {/* Duty assignment summary */}
          <div className="rounded-xl border border-slate-200 bg-white">
            <div className="border-b border-slate-100 px-4 py-3">
              <h3 className="text-sm font-semibold text-ink">
                Duty assignment summary · {dutyRows.length} sent on duty
              </h3>
            </div>
            {dutyRows.length === 0 ? (
              <p className="px-4 py-6 text-sm text-slate-400">No PCs sent on duty for this date.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="px-3 py-2">PC / G.No</th>
                      <th className="px-3 py-2">Name</th>
                      <th className="px-3 py-2">Unit</th>
                      <th className="px-3 py-2">Duty location</th>
                      <th className="px-3 py-2">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {dutyRows.map((r) => (
                      <tr key={r.id}>
                        <td className="px-3 py-2 font-semibold text-ink">{r.pcNumber}</td>
                        <td className="px-3 py-2">{r.name || "—"}</td>
                        <td className="px-3 py-2">{r.unit || "—"}</td>
                        <td className="px-3 py-2">{r.dutyLocation || "—"}</td>
                        <td className="px-3 py-2">{r.dutyRemarks || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* PC-wise detail table */}
          <div className="print-area rounded-xl border border-slate-200 bg-white">
            <div className="no-print border-b border-slate-100 px-4 py-3">
              <h3 className="text-sm font-semibold text-ink">PC-wise detail</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-left text-sm">
                <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-3 py-2">#</th>
                    <th className="px-3 py-2">PC / G.No</th>
                    <th className="px-3 py-2">Rank</th>
                    <th className="px-3 py-2">Name</th>
                    <th className="px-3 py-2">Unit</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Present time</th>
                    <th className="px-3 py-2">Duty / remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {data.rows.map((r) => (
                    <tr key={r.id}>
                      <td className="px-3 py-2 text-slate-400">{r.slNo}</td>
                      <td className="px-3 py-2 font-semibold text-ink">{r.pcNumber}</td>
                      <td className="px-3 py-2">{r.rank}</td>
                      <td className="px-3 py-2">{r.name || "—"}</td>
                      <td className="px-3 py-2">{r.unit || "—"}</td>
                      <td className="px-3 py-2">
                        <StatusBadge status={r.status} />
                      </td>
                      <td className="px-3 py-2 text-slate-600">{formatIstTime(r.presentAt)}</td>
                      <td className="px-3 py-2 text-slate-600">
                        {[r.dutyLocation, r.dutyRemarks].filter(Boolean).join(" · ") || "—"}
                      </td>
                    </tr>
                  ))}
                  {data.rows.length === 0 && (
                    <tr>
                      <td colSpan={8} className="px-3 py-8 text-center text-slate-400">
                        No PCs on this roster.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
