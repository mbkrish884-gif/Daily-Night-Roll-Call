import { getActiveHq } from "@/lib/hq";
import { SettingsForm } from "@/components/SettingsForm";
import { ROLL_CALL_TIME } from "@/lib/config";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const hq = await getActiveHq();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-ink">Settings</h1>
        <p className="text-sm text-slate-500">HQ geofence and attendance configuration.</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-200 bg-white p-3">
          <div className="text-xs font-medium text-slate-500">Current centre</div>
          <div className="text-sm font-semibold text-ink">
            {hq.latitude.toFixed(6)}, {hq.longitude.toFixed(6)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3">
          <div className="text-xs font-medium text-slate-500">Radius</div>
          <div className="text-sm font-semibold text-ink">{hq.radiusM} m</div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3">
          <div className="text-xs font-medium text-slate-500">Roll call time</div>
          <div className="text-sm font-semibold text-ink">{ROLL_CALL_TIME}</div>
        </div>
      </div>

      <SettingsForm
        hq={{
          name: hq.name,
          mapsUrl: hq.mapsUrl,
          latitude: hq.latitude,
          longitude: hq.longitude,
          radiusM: hq.radiusM,
        }}
      />

      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <h3 className="text-sm font-semibold text-ink">Direct attendance link</h3>
        <p className="mt-1 text-sm text-slate-600">
          Share this link with PCs (WhatsApp / SMS). It opens the simple mobile form — no login needed,
          attendance only:
        </p>
        <code className="mt-2 block rounded-md bg-slate-100 px-3 py-2 text-sm text-slate-700">
          {"<your-domain>/attend"}
        </code>
      </div>
    </div>
  );
}
