import { prisma } from "@/lib/db";
import { toDayKey, todayKey, formatDay } from "@/lib/date";
import { RosterManager } from "@/components/RosterManager";
import { DateNav } from "@/components/DateNav";

export const dynamic = "force-dynamic";

export default async function RosterPage({ searchParams }: { searchParams: { date?: string } }) {
  const date = toDayKey(searchParams.date ?? todayKey());
  const roster = await prisma.dailyRoster.findUnique({
    where: { date },
    include: { entries: { orderBy: { slNo: "asc" }, include: { pc: true } } },
  });

  const existing = (roster?.entries ?? []).map((e) => ({
    pcNumber: e.pc.pcNumber,
    rank: e.pc.rank,
    name: e.pc.name ?? "",
    unit: e.pc.unit ?? "",
    mobile: e.pc.mobile ?? "",
    dutyRemarks: e.dutyRemarks ?? "",
  }));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink">Roster Management</h1>
          <p className="text-sm text-slate-500">
            {formatDay(date)} · {existing.length} PC{existing.length === 1 ? "" : "s"} currently on roster
          </p>
        </div>
        <DateNav date={date} basePath="/admin/roster" />
      </div>

      <RosterManager
        date={date}
        platoon={roster?.platoon ?? "NIGHT"}
        rollCallTime={roster?.rollCallTime ?? "19:00"}
        instructions={roster?.instructions ?? ""}
        existing={existing}
      />
    </div>
  );
}
