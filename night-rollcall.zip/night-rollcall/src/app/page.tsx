import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-khaki-dark px-5 text-center">
      <div className="w-full max-w-md">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-3xl text-white ring-1 ring-white/30">
          ★
        </div>
        <h1 className="text-2xl font-bold text-white">Night Roll Call</h1>
        <p className="mt-1 text-sm text-white/70">CAR Headquarters, Hyderabad</p>

        <div className="mt-8 space-y-3">
          <Link
            href="/attend"
            className="block rounded-xl bg-white px-5 py-4 text-base font-semibold text-khaki-dark shadow-lg transition hover:bg-slate-50"
          >
            Mark Attendance
          </Link>
          <Link
            href="/login"
            className="block rounded-xl border border-white/40 px-5 py-4 text-base font-semibold text-white transition hover:bg-white/10"
          >
            Admin Dashboard
          </Link>
        </div>

        <p className="mt-8 text-xs text-white/50">
          Attendance is permitted only inside the HQ geofence at 7:00 PM roll call.
        </p>
      </div>
    </main>
  );
}
