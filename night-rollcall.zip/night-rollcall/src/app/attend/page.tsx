"use client";

import { useState } from "react";

type Step = "enter" | "status" | "done";
interface PcInfo {
  pcNumber: string;
  rank: string;
  name: string | null;
  unit: string | null;
}

const STATUS_BUTTONS: { value: string; label: string; cls: string }[] = [
  { value: "PRESENT", label: "Present at HQ", cls: "bg-green-600 hover:bg-green-700" },
  { value: "AVAILABLE", label: "Available at HQ", cls: "bg-blue-600 hover:bg-blue-700" },
  { value: "OFF", label: "Off", cls: "bg-amber-600 hover:bg-amber-700" },
  { value: "ABSENT", label: "Absent", cls: "bg-rose-600 hover:bg-rose-700" },
];

export default function AttendPage() {
  const [step, setStep] = useState<Step>("enter");
  const [pcNumber, setPcNumber] = useState("");
  const [pcInfo, setPcInfo] = useState<PcInfo | null>(null);
  const [meta, setMeta] = useState<{ date: string; rollCallTime: string; platoon: string } | null>(null);
  const [remarks, setRemarks] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null);

  async function lookup(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const res = await fetch(`/api/attendance/lookup?pc=${encodeURIComponent(pcNumber.trim())}`);
      const data = await res.json();
      if (!res.ok || !data.ok) {
        setError(data.error || "Could not find this PC number.");
        return;
      }
      setPcInfo(data.pc);
      setMeta({ date: data.date, rollCallTime: data.rollCallTime, platoon: data.platoon });
      if (data.status === "PRESENT") {
        setResult({ ok: true, message: "You are already marked Present for tonight." });
        setStep("done");
      } else {
        setStep("status");
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  function getPosition(): Promise<GeolocationPosition> {
    return new Promise((resolve, reject) => {
      if (!("geolocation" in navigator)) {
        reject(new Error("This device does not support location."));
        return;
      }
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      });
    });
  }

  async function submit(status: string) {
    setError(null);
    setBusy(true);
    try {
      const payload: Record<string, unknown> = { pcNumber: pcInfo!.pcNumber, status };
      if (remarks.trim()) payload.remarks = remarks.trim();

      if (status === "PRESENT") {
        let pos: GeolocationPosition;
        try {
          pos = await getPosition();
        } catch (e) {
          const err = e as GeolocationPositionError | Error;
          const denied = "code" in err && err.code === 1;
          setError(
            denied
              ? "Location permission is required to mark Present. Please enable GPS and allow access."
              : "Could not get your location. Move to an open area and try again."
          );
          setBusy(false);
          return;
        }
        payload.latitude = pos.coords.latitude;
        payload.longitude = pos.coords.longitude;
        payload.accuracyM = pos.coords.accuracy;
      }

      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();

      if (res.status === 403 && data.blocked) {
        setError(`${data.error} You are about ${data.distanceM} m away (allowed ${data.allowedM} m).`);
        setBusy(false);
        return;
      }
      if (!res.ok || !data.ok) {
        setError(data.error || "Submission failed.");
        setBusy(false);
        return;
      }
      setResult({ ok: true, message: data.message });
      setStep("done");
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    setStep("enter");
    setPcNumber("");
    setPcInfo(null);
    setRemarks("");
    setError(null);
    setResult(null);
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col bg-slate-50">
      <header className="bg-khaki-dark px-5 py-4 text-white">
        <h1 className="text-lg font-bold">Night Roll Call</h1>
        <p className="text-xs text-white/70">CAR Headquarters, Hyderabad</p>
      </header>

      <div className="flex-1 px-5 py-6">
        {step === "enter" && (
          <form onSubmit={lookup} className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-700">
                Enter your PC / G.No
              </label>
              <input
                className="field text-center text-2xl font-bold tracking-wider"
                inputMode="numeric"
                placeholder="e.g. 11809"
                value={pcNumber}
                onChange={(e) => setPcNumber(e.target.value)}
                autoFocus
                required
              />
            </div>
            {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}
            <button type="submit" className="btn-primary w-full py-4 text-base" disabled={busy}>
              {busy ? "Checking…" : "Continue"}
            </button>
            <p className="text-center text-xs text-slate-400">
              Only PCs on tonight&apos;s roster can mark attendance.
            </p>
          </form>
        )}

        {step === "status" && pcInfo && (
          <div className="space-y-5">
            <div className="rounded-xl border border-slate-200 bg-white p-4">
              <p className="text-xs uppercase tracking-wide text-slate-400">Confirm identity</p>
              <p className="mt-1 text-lg font-bold text-ink">
                {pcInfo.rank} {pcInfo.pcNumber}
              </p>
              <p className="text-sm text-slate-600">
                {pcInfo.name || "Name not on file"}
                {pcInfo.unit ? ` · ${pcInfo.unit}` : ""}
              </p>
              {meta && (
                <p className="mt-1 text-xs text-slate-400">
                  {meta.platoon} platoon · roll call {meta.rollCallTime}
                </p>
              )}
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Remarks (optional)
              </label>
              <textarea
                className="field min-h-[72px]"
                placeholder="Any note for the duty officer"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />
            </div>

            <div>
              <p className="mb-2 text-sm font-semibold text-slate-700">Mark your status</p>
              <div className="grid grid-cols-1 gap-3">
                {STATUS_BUTTONS.map((b) => (
                  <button
                    key={b.value}
                    onClick={() => submit(b.value)}
                    disabled={busy}
                    className={`btn w-full py-4 text-base text-white ${b.cls}`}
                  >
                    {b.value === "PRESENT" && busy ? "Verifying location…" : b.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-center text-xs text-slate-400">
                Marking <b>Present</b> verifies you are inside the HQ premises and saves the exact time.
              </p>
            </div>

            {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

            <button onClick={reset} className="btn-ghost w-full">
              ← Use a different PC number
            </button>
          </div>
        )}

        {step === "done" && (
          <div className="space-y-5 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-3xl text-green-600">
              ✓
            </div>
            <div>
              <h2 className="text-xl font-bold text-ink">Recorded</h2>
              <p className="mt-1 text-slate-600">{result?.message}</p>
              {pcInfo && (
                <p className="mt-2 text-sm text-slate-400">
                  {pcInfo.rank} {pcInfo.pcNumber} · {meta?.date}
                </p>
              )}
            </div>
            <button onClick={reset} className="btn-primary w-full py-4">
              Mark another PC
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
